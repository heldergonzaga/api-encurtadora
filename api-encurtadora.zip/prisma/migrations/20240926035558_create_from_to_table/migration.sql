-- CreateTable
CREATE TABLE "TabelaEncurtadoras" (
    "id" TEXT NOT NULL,
    "term_origin" TEXT NOT NULL,
    "term_target" TEXT NOT NULL,

    CONSTRAINT "TabelaEncurtadoras_pkey" PRIMARY KEY ("id")
);
